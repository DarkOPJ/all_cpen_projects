from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'./temps/userdash.html')

def announce(request):
    return render(request,'./temps/announcements.html')

def assign(request):
    return render(request,'./temps/assignment.html')

def result(request):
    return render(request,'./temps/checkresult.html')

def lannounce(request):
    return render(request,'./temps/lectannounce.html')

def lupload(request):
    return render(request,'./temps/lectupload.html')

def ldash(request):
    return render(request,'./temps/lecturerdash.html')
