from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='users-dash'),
    path('announcements/',views.announce,name='users-announce'),
    path('assignments/',views.assign,name='users-assign'),
    path('results/',views.result,name='users-result'),
    path('lectannounce/',views.lannounce,name='lect-announce'),
    path('lectupload/',views.lupload,name='lect-upload'),
    path('lecturerdash/',views.ldash,name='lect-dash'),
]