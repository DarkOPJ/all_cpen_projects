from django.db import models

# Create your models here.
class Student(models.Model):
    id = models.CharField(primary_key=True, max_length=8)
    first_name = models.CharField(max_length=30)
    middle_name = models.CharField(max_length=30, blank=True, null=True)
    last_name = models.CharField(max_length=30)
    email = models.CharField(max_length=50, blank=True, null=True)
    password = models.CharField(max_length=50)

    class Meta:
        managed = False
        db_table = 'student'

class file(models.Model):
    name=models.CharField(max_length=50)
    lecturer=models.CharField(max_length=50)
    date=models.DateTimeField(auto_now_add=True)
    file=models.FileField()