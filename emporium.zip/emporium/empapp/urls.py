from django.urls import path
from . import views

urlpatterns = [
    path('', views.welcome, name = 'empapp-welcome'),
    path('login/', views.login1, name='empapp-login'),
    path('logout/', views.logout1, name='empapp-logout'),
    path('signup/', views.signup, name='empapp-signup'),
    path('stud_dashboard/', views.stud_dashboard, name='empapp-stud-dashboard'),
    path('assignment/', views.assignment, name='empapp-assignment'),
    path('annoncement/', views.announcement, name='empapp-announcement'),
    path('checkresult/', views.checkresult, name='empapp-checkresult'),
]