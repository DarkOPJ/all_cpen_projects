from django.contrib import admin
from . models import Student, file
# Register your models here.

class StudentAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'first_name', 'middle_name', 'last_name', 'password'
    ]

admin.site.register(Student, StudentAdmin)     
admin.site.register(file)              