from multiprocessing import context
from django.contrib import messages
from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout

from empapp.models import file
from . forms import CreateUserForm
from django.contrib.auth.decorators import login_required
# Create your views here.

def welcome(request):
    return render(request, './welcome.html')


def signup(request):
    if request.user.is_authenticated:
        return redirect('empapp-stud-dashboard')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('first_name')
                messages.success(request, user + ', your account was successfully created.')
                return redirect('empapp-login')
        else:
            form = CreateUserForm()

    context = {
        'form' : form
    }
    
    return render(request, 'signup.html', context)

def login1(request):
    if request.user.is_authenticated:
        return redirect('empapp-stud-dashboard')
    else:
        
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('empapp-stud-dashboard')
            else:
                messages.error(request, 'Username or password incorrect')

    context = {
        
    }
    return render(request, 'login.html')


@login_required(login_url='login1')
def stud_dashboard(request):
    return render(request, 'stud_dashboard.html')

def logout1(request):
    logout(request)
    return redirect('empapp-login')

def assignment(request):
    
    context={
        'file':file.objects.all(),
    }
    return render(request, 'assignment.html',context)

def announcement(request):
    return render(request, 'announcements.html')

def checkresult(request):
    return render(request, 'checkresult.html')
