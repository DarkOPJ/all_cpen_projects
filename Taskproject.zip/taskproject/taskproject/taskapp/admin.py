from django.contrib import admin
from . models import TaskModel
# Register your models here.

class TaskModelAdmin(admin.ModelAdmin):
    list_display = ['task', 'isCompleted', 'date']

admin.site.register(TaskModel, TaskModelAdmin)