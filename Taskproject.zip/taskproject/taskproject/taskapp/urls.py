from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='taskapp-index'),
    path('about/', views.about, name='taskapp-about'),
    path('edit/<int:pk>/', views.edit, name='taskapp-edit'),
    path('delete/<int:pk>/', views.delete, name='taskapp-delete'),
]