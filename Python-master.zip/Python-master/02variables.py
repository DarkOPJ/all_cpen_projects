# A variable is a placeholder for storing data in the computer memory
#from keyword import kwlist

#print(kwlist)
firstName="Stephen"
last_name='Nortey'
Number=90
age=30
AGE=40
Age=60
#print(firstName)
print(age)


# VARIABLE NAMING RULES
# 1. Use descriptive names
# 2. Cannot use white spaces and hyphen in between names
# 3. Use underscore
# 4. Use camelCase notation
# 5. Cannot start with a number but can have a number in it
# 6. Cannot use reserved keywords
# 7. Python is case-sensitive


# Multiple Assignment or Unpacking
x=40
y=50

x,y=40, 50