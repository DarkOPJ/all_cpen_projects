# Python arithmetic operations + - * / // % **

# Addition +
# x=5
# y=4
# z=5/4
# print(z)
# Subtraction -

# # Multiplication *

# # Division /
# x=11
# y=4
# z=x/y
# print(z)
# # Floor Division //
# x=11
# y=4
# z=x//y
# print(z)
# # Power **
# x=5
# y=4
# z=5**4
# print(z)
# # Modulus %
# x=5
# y=4
# z=5%4
# print(z)
# Math functions

# round
# x=4.789

# print(round((x),2))
# absolute value
x=-20

print(abs(x))