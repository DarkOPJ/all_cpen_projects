# Python input function
