# Python list is a collection which is ordered and mutable.
# It allows duplicate members
names = ['Kenneth', 'Jaymills', 'Jaymills', '1DON', 89]

names [0]= 'Broni'
print(type(names))
print(names[-1])
# len fucntion

# LIST METHODS
# Append -- Adds an element at the end of the list
names.append('Nii')
print(names)
# Clear -- Removes all the elements from the list

# Copy -- Returns a copy of the list

# Count -- Returns the number of elements with the specified value

# Index -- Returns the index of the first element with the specified value

# Sort -- Sorts the list

# Reverse -- Reverses the order of the list

# Remove -- Removes the first item with the specified value

# Pop -- Removes the element at the specified position
