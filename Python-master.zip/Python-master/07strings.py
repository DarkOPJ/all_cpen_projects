# Python string and methods

# When to use single or double quotation marks

# Indexing
#school='University of Ghana'
#       0123456789
#print(school[3:9])
# len function
#print(len(school))
# STRING METHODS


# Capitalize -- Converts the first character to uppercase
# school=school.capitalize()
# print(school)
# Count -- Returns the number of times a specified character occurs in a string
#school='university of ghana'
# x=school.count('a')
# print(x)
# Find -- Searches the string for a specified value and returns the position of where it was found
# school='university of ghana'
# x=school.find('a')
# print(x)
# Replace -- Replaces a specified value with another
# school='university of ghana'
# name=school.replace('ghana','cape coast')
# print(name)
# Index -- Searches the string for a specified value and returns the position of where it was found
# school='university of ghana'
# name=school.index('q')
# print(name)
# Lower -- Converts a string into lower case
# school='university of ghana'
# name=school.upper()
# print(name)
# Upper -- Converts a string into upper case

# Isalnum -- Returns True if all characters in the string are alphanumeric
# password= 'tuhriskdji ieji '

# print(password.isalnum())
# Isdigit -- Returns True if all characters in the string are digits

# Isspace -- Returns True if all characters in the string are whitespaces

# Split -- Splits the string at the specified separator, and returns a list
# school='university of ghana'
# name=school.split(" ")
# print(name)
# Startwith -- Returns true if the string starts with the specified value

# Endwith -- Returns true if the string ends with the specified value
# files= 'image.png'

# print(files.endswith('.png'))