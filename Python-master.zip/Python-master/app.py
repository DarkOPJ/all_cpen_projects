# print('Hello world')

# print('Stephen Nortey')

def addFunction(x,y):
    z= x + y
    return z

def subFunction(x,y):
    z= x - y
    return z
    
def prodFunction(x,y):
    z= x * y
    return z

print(addFunction(3,5))
