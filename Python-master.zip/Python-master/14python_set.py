# Python set is a collection which is unordered and not mutable.
# It does not allow duplicate members


# Union and Intersection

# Difference
