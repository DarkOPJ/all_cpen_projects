# Python operators 
# These operators are used in combination with other conditional statements and operators

# Membership Operators
# in 

# not in


# Logical Operators 

# and

# or

# not
