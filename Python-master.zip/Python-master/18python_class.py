# A class is a blue-print for creating objects.

# Creating an object

# Person Class

# INHERITANCE

# Student Class

# Lecturer Class

# Overwrite string method
