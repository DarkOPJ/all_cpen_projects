# Python comparison operators #  == < > <= >= !=
# Comparison operators are used to compare two or more values
x=10
y=20
z=10

print(x<=y)
# Equal to ==


# Not Equal to !=


# Greater than >


# Less than <

# Grater than or equal to >=

# Less than or equal to <=

# Assignment Operator: = += -= *=
x = 3
x *= 4
print(x)