# Python First Program
# Comments
# Comments are non-executable notes written to give the programmer some information on the kind of programming logic being implemented


# Python language order of execution
