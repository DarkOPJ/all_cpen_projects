# Data is the value stored inside a variable.

# String -- str
# String is a collection of data types declared with either a single or double quotation mark wrapped around it


# Integer -- int
# Integer is a positive or negative whole number


# Float -- float
# A float is a fraction or decimal value


# Complex -- complex
# A complex number is a number which consist of a real part and an imaginary part.

# Boolean -- bool
# A boolean data type which represents data that can only exist in two forms.
