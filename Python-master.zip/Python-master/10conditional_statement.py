# Python conditional statement if else elif
# score = int(input('Enter score: '))


# if score >= 90:
#     print('Grade: A')
# elif 70 <= score <= 80:
#     print('Grade: B')
# else:
#     print('Grade not A')
# EXERCISE

# Program takes two inputs and checks which of the inputs is greater
number1 = int(input('Enter 1st number: '))
number2 = int(input('Enter 2nd number: '))

if number1 > number2:
    print(f'{number1} is greater than {number2}')
else:
    print(f'{number1} is less than {number2}')

# Check Odd or Even numbers

# Grade check results:
# User input score and grade displays in the terminal
