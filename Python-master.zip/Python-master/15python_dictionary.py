# Python dictionary is a collection of key value pair of data.
# It is ordered and mutable.
# It allows duplicate members

# Dictionary Methods

# Copy -- Returns a copy of the dictionary

# Clear -- Removes all the elements from the dictionary

# Pop -- Removes the element with the specified key

# Keys -- Returns a list containing the dictionary's keys

# Values -- Returns a list containing the dictionary's values
