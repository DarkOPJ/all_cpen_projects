# Python Libraries and Frameworks

# Python libraries are published onto the official python package index [https://pypi.org/]

# kbtcal

# Numpy

# Pandas

# Matplotlib

# QRCode Application

# Build an AudioBook in Python

# folium

# Django
