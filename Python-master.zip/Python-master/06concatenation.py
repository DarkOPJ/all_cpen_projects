# Python concatenation
# This simply means joining two or more string values together

# firstName='Stephen '
# lastName='Nortey'
# fullName=firstName+lastName
# print(fullName)

# x='20'
# y='30'
# z=x+y
# print(z)

#  name='Stephen'
#  nationality='Ghanaian'

# statement='My name is {} and I am a {}'.format(name, nationality)
# print(statement)
name='Stephen'
nationality='Ghanaian'

statement= f'My name is {name} and I am a {nationality}'
print(statement)

# Formatted String
