# import app

# # results = app.addFunction(3,7)
# # print(results)

# from app import *

# results = addFunction(5,2)
# print(results)
from ug.se.CPEN.app import addFunction

