# Loop
# For loop

# while True:

# Loop through List

# Loop through multiple Lists simultaneously using zip nethod

# Range method and loops


# Exercise
# 1. Find all the even numbers in a range
# 2. Find the sum of all elements in a list
