# Python tuple is a collection which is ordered.
# A tuple is not mutable
# It allows duplicate members
colors = ('blue','red','yellow')

#colors[0]='orange'
colors.append('black')
print(colors)

num=(2, 5)
print(num)
x,y=num
# Unpack Tuple

# Tupple Methods
