# A Python module is a python file, that consists of some python codes. These codes can be used in other python programs.
