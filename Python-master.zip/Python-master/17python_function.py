# A function is a block of code that is executed when it is called
# from unicodedata import name
# name = 'Kenneth'
# print(name)

# def greet(name='Esi'):
#     print(f'Hello {name}')

# greet()

# A parameter is the variable listed inside the parentheses in the function definition.
# An argument is the value that is sent to the function when it is called.


# Functions with Parameters and Argument
# def addfunction(x,y):
#     z=x+y
#     return z


# print(addfunction(3,5))

# name ='Ken'

# type(name)
# It is important to be mindful of indentation
# x,*y=5,6,7,8

# non-keywords arguments and keyword arguments [ *args and **kwargs ]
# import numbers


# def sumfunction(*args):
#     total=0
#     for x in args:
#         total += x
#     return total

    
# print(sumfunction(2,3,4,6))

# numbers = [3,4,6,2,5]
# task = ['Learn Python','Visit Library','Do homework']

# for num in numbers:
#     print(num)
# print(numbers)

# from unicodedata import name


# def greet(**kwargs):
#     print(kwargs)
#     print(type(kwargs))

# print (greet(name='Ken', age=20))
from . import views

urlpatterns = [
    path('', views.index, name='taskapp-index')
    path('about/', views.about, name='taskapp-about')
    path('profile/', views.index, name='taskapp-profile')
]

www.1don.com
www.1don.com/about
www.1don.com/profile

def index(request):
    return render(resuest, 'taskapp/index.html')