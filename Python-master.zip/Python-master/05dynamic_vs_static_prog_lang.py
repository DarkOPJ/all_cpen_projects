# Dynamic vs Static Programming Languages
